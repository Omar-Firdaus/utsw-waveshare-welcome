# UT Southwestern recorder — Waveshare 1.85C V2

Open UTSW_Splash.ino together with every file in this folder in Arduino IDE.
The start screen says **V2 audio / build 4**. The recorder header says
**Voice recorder V2** and includes a labeled microphone meter and Test speaker.

## Working build settings
- ESP32S3 Dev Module; esp32 core 3.1.1 (compiled successfully with this core)
- Flash Size: 16MB (128Mb)
- PSRAM: OPI PSRAM
- Partition: 16M Flash (3MB APP/9.9MB FATFS), not ESP SR
- USB CDC On Boot: Enabled
- USB Mode: Hardware CDC and JTAG
- Waveshare bundled LVGL 8.3.10 already installed on this Mac

The existing display driver and LVGL version are retained. Audio uses the
ES8311 and ES7210 drivers from Waveshare's official V2 repository, bundled here;
no extra audio libraries, speech model, SD card, or network are required.

## Use
Start plays a two-note chime and opens the recorder. Hold to record, speak,
and release to play the clip once. The timer and Mic percentage/bar show capture.
A hold records up to 30 seconds; at the limit capture stops and playback waits
for release. Test speaker plays two tones independently of the microphone.
The record button is unavailable during playback.

Clips are kept in 960,000 bytes of PSRAM, cleared after playback, and never saved
or uploaded. Input is 16kHz 16-bit stereo ES7210 audio, selecting the stronger
microphone channel for mono storage and duplicating it for playback.
Playback has clipping protection and short fades. RX is enabled only for capture.
The shared I2S clock keeps running; the amplifier is enabled only for output.

## V2 hardware
Shared I2S0 bus: MCLK 2, BCLK 48, WS 38, speaker DOUT 47, microphone DIN 39.
GPIO15 is amplifier enable. ES8311 at I2C address 0x18; ES7210 at 0x40.
Codecs initialize in setup before LVGL starts polling touch on the same I2C bus.
Do not use the older V1 MSM261/PCM5101 audio pins on this V2 board.

## Diagnostics
Serial Monitor at 115200 prints firmware build, responding I2C addresses,
codec initialization, touch transitions, and recorded playback duration.
No tones from Test speaker indicates output/codec/speaker trouble independent
of microphone capture. A static zero meter indicates no microphone samples
of measurable amplitude; a non-counting timer indicates capture isn't active.

## Sources
Official V2 code: https://github.com/waveshareteam/ESP32-S3-Touch-LCD-1.85C
Audio drivers copied from Arduino/examples/03_audio_out_no_tf and 08_esp_sr.
Their source copyright notices and Apache license are included.
Official logo: https://brand.utswmed.org/documents/1378/master-logo-reversed-white.png
Background: #004C97; static white logo; Start button 220px wide.

## Verified on the connected V2 board
The build was uploaded through Arduino IDE. Serial diagnostics confirmed
ES8311 initialize/volume/analog mode and ES7210 initialize/digital gain all
returned ESP_OK. A touch recording and 960ms playback were observed in the log.
The user confirmed audible speaker tones, voice playback after release, and a
responsive microphone meter on the connected V2 board.

The vendor example's ES7210 digital volume of 40 is outside the driver's
supported -95..32 dB range. This application uses 0 dB digital gain and retains
the reference 36 dB analog microphone gain. Source driver files are unchanged.

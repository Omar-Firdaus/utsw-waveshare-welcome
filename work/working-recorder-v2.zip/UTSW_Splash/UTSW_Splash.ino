#include "LVGL_Driver.h"
#include "utsw_logo.h"
#include "VoiceRecorder.h"
#include <math.h>

static lv_img_dsc_t logo;

static lv_obj_t *record_button, *record_label, *status_label, *time_label;
static lv_obj_t *start_button, *mic_meter, *speaker_button, *meter_label;
static bool recorder_open = false;

static lv_obj_t *make_button(lv_obj_t *parent, const char *text, int width, int height, int y) {
  lv_obj_t *button = lv_btn_create(parent);
  lv_obj_set_size(button, width, height);
  lv_obj_align(button, LV_ALIGN_CENTER, 0, y);
  lv_obj_set_style_radius(button, height / 2, 0);
  lv_obj_set_style_bg_color(button, lv_color_white(), 0);
  lv_obj_set_style_bg_opa(button, LV_OPA_COVER, 0);
  lv_obj_set_style_bg_color(button, lv_color_hex(0xD9E8F7), LV_STATE_PRESSED);
  lv_obj_set_style_shadow_width(button, 0, 0);
  lv_obj_set_style_border_width(button, 0, 0);
  lv_obj_set_style_text_color(button, lv_color_hex(0x004C97), 0);
  lv_obj_t *label = lv_label_create(button);
  lv_label_set_text(label, text);
  lv_obj_center(label);
  return button;
}

static lv_obj_t *make_label(lv_obj_t *parent, const char *text, int y) {
  lv_obj_t *label = lv_label_create(parent);
  lv_label_set_text(label, text);
  lv_obj_set_style_text_color(label, lv_color_white(), 0);
  lv_obj_align(label, LV_ALIGN_CENTER, 0, y);
  return label;
}

static void record_event(lv_event_t *event) {
  lv_event_code_t code = lv_event_get_code(event);
  if (code == LV_EVENT_PRESSED && recorder_state() == RecorderState::Ready) {
    recorder_hold(true);
  } else if (code == LV_EVENT_RELEASED || code == LV_EVENT_PRESS_LOST) {
    recorder_hold(false);
  }
}

static void speaker_event(lv_event_t *) {
  if (recorder_state() == RecorderState::Ready) recorder_chime();
}

static void start_event(lv_event_t *event) {
  if (recorder_open || recorder_state() != RecorderState::Ready) return;
  recorder_chime();
  recorder_open = true;
  lv_obj_t *screen = lv_scr_act();
  lv_obj_clean(screen);
  start_button = nullptr;
  make_label(screen, "Voice recorder V2", -108);
  status_label = make_label(screen, "Opening...", -78);
  time_label = make_label(screen, "00:00 / 00:30", -23);
  mic_meter = lv_bar_create(screen);
  lv_obj_set_size(mic_meter, 200, 12);
  lv_obj_set_style_border_width(mic_meter, 1, LV_PART_MAIN);
  lv_obj_set_style_border_color(mic_meter, lv_color_white(), LV_PART_MAIN);
  lv_obj_align(mic_meter, LV_ALIGN_CENTER, 0, -2);
  lv_bar_set_range(mic_meter, 0, 100);
  lv_obj_set_style_bg_color(mic_meter, lv_color_hex(0x326FAD), LV_PART_MAIN);
  lv_obj_set_style_bg_color(mic_meter, lv_color_hex(0x7BE2AD), LV_PART_INDICATOR);
  meter_label = make_label(screen, "Mic: 0%", -43);
  record_button = make_button(screen, "Hold to record", 224, 72, 40);
  record_label = lv_obj_get_child(record_button, 0);
  lv_obj_add_event_cb(record_button, record_event, LV_EVENT_ALL, nullptr);
  lv_obj_add_state(record_button, LV_STATE_DISABLED);
  make_label(screen, "Release to play back once", 94);
  speaker_button = make_button(screen, "Test speaker", 144, 32, 128);
  lv_obj_add_event_cb(speaker_button, speaker_event, LV_EVENT_CLICKED, nullptr);
}

static void update_recorder_ui(lv_timer_t *) {
  RecorderState state = recorder_state();
  if (!recorder_open) {
    if (state == RecorderState::Ready) lv_obj_clear_state(start_button, LV_STATE_DISABLED);
    else if (state == RecorderState::Error) {
      lv_label_set_text(lv_obj_get_child(start_button, 0), "Audio unavailable");
    }
    return;
  }
  const char *status = "Ready to record";
  const char *button = "Hold to record";
  bool busy = false;
  switch (state) {
    case RecorderState::Starting: status = "Preparing audio..."; busy = true; break;
    case RecorderState::Chime: status = "Opening..."; busy = true; break;
    case RecorderState::Recording: status = "Recording"; button = "Release to play"; break;
    case RecorderState::Full: status = "30-second limit reached"; button = "Release to play"; break;
    case RecorderState::Playing: status = "Playing back"; button = "Playing..."; busy = true; break;
    case RecorderState::Error: status = "Audio error - restart device"; button = "Unavailable"; busy = true; break;
    default: break;
  }
  if (state == RecorderState::Ready) lv_obj_clear_state(speaker_button, LV_STATE_DISABLED);
  else lv_obj_add_state(speaker_button, LV_STATE_DISABLED);
  // Logarithmic meter makes normal speech visible without showing silence
  // as a full-scale signal. Audio remains local and only capture is metered.
  uint32_t peak = recorder_level();
  int meter = peak ? constrain(int(20.0f * log10f(float(peak) / 32768.0f) + 60.0f) * 100 / 60, 0, 100) : 0;
  lv_bar_set_value(mic_meter, meter, LV_ANIM_OFF);
  lv_label_set_text_fmt(meter_label, "Mic: %d%%", meter);
  lv_label_set_text(status_label, status);
  lv_label_set_text(record_label, button);
  if (busy) lv_obj_add_state(record_button, LV_STATE_DISABLED);
  else lv_obj_clear_state(record_button, LV_STATE_DISABLED);
  bool recording = state == RecorderState::Recording || state == RecorderState::Full;
  lv_obj_set_style_bg_color(record_button, lv_color_hex(recording ? 0xFFDADA : 0xFFFFFF), 0);
  uint32_t seconds = recorder_milliseconds() / 1000;
  lv_label_set_text_fmt(time_label, "%02lu:%02lu / 00:30", (unsigned long)(seconds / 60), (unsigned long)(seconds % 60));
}

void setup() {
  Serial.begin(115200);
  delay(1500);
  Serial.println("UTSW V2 audio build 4");
  I2C_Init();
  for (uint8_t address = 8; address < 120; ++address) {
    Wire.beginTransmission(address);
    if (Wire.endTransmission() == 0) Serial.printf("I2C device 0x%02X\n", address);
  }
  TCA9554PWR_Init(0x00);
  Backlight_Init();
  Set_Backlight(0);
  LCD_Init();
  Lvgl_Init();

  lv_obj_t *screen = lv_scr_act();
  lv_obj_clean(screen);
  lv_obj_clear_flag(screen, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_style_bg_color(screen, lv_color_hex(0x004C97), 0);
  lv_obj_set_style_bg_opa(screen, LV_OPA_COVER, 0);
  lv_obj_set_style_border_width(screen, 0, 0);
  lv_obj_set_style_pad_all(screen, 0, 0);

  logo.header.always_zero = 0;
  logo.header.w = 280;
  logo.header.h = 56;
  logo.header.cf = LV_IMG_CF_ALPHA_8BIT;
  logo.data_size = sizeof(utsw_logo_alpha);
  logo.data = utsw_logo_alpha;
  lv_obj_t *image = lv_img_create(screen);
  lv_img_set_src(image, &logo);
  lv_obj_set_style_img_recolor(image, lv_color_white(), 0);
  lv_obj_set_style_img_recolor_opa(image, LV_OPA_COVER, 0);
  lv_obj_center(image);

  start_button = make_button(screen, "Start", 220, 52, 86);
  lv_obj_add_state(start_button, LV_STATE_DISABLED);
  lv_obj_add_event_cb(start_button, start_event, LV_EVENT_CLICKED, nullptr);
  make_label(screen, "V2 audio / build 4", 132);
  recorder_begin();
  lv_timer_create(update_recorder_ui, 50, nullptr);
  lv_refr_now(NULL);
  Set_Backlight(80);
  Serial.println("UTSW voice recorder ready");
}

void loop() {
  Lvgl_Loop();
  delay(5);
}

#pragma once
#include <stdint.h>
enum class RecorderState { Starting, Ready, Chime, Recording, Full, Playing, Error };
void recorder_begin();
void recorder_chime();
void recorder_hold(bool held);
RecorderState recorder_state();
uint32_t recorder_milliseconds();

uint32_t recorder_level();
